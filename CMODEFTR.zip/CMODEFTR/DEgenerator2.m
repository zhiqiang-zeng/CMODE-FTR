function [Offspring] = DEgenerator2(Population,Problem)

%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    cv = sum(max(0,Population.cons),2);       

    FrontNo = NDSort(Population.objs,Population.cons,1);
    
   
%     FrontNo = NDSort(Population.objs,Population.cons,inf);
    

%     index1  = find(FrontNo==1);
%     r       = floor(rand*length(index1))+1;
%     best    = index1(r);

    [N,D] = size(Population(1).decs);       
    trial = zeros(1*Problem.N,D);
       
    for i = 1 : Problem.N   
        
        index1  = find(FrontNo==1);
        r       = floor(rand*length(index1))+1;
        best    = index1(r);
        

  
     
            

            indexset    = 1 : Problem.N;
            indexset(i) = [];
            r1  = floor(rand*(Problem.N-1))+1;
            xr1 = indexset(r1);
            indexset(r1) = [];
            r2  = floor(rand*(Problem.N-2))+1;
            xr2 = indexset(r2)  ;
            r3  = floor(rand*(Problem.N-3))+1;
            xr3 = indexset(r3);
            Best_index = Population(best).decs;





if rand<=0.5
    

   
    CR=0.1;
    if rand<0.5
        F_pool=[0.6,0.8,1.0];
        F=F_pool(randi(3));
        v=Population(xr1).decs+rand*(Best_index-Population(xr1).decs)+F*(Population(xr2).decs-Population(xr3).decs);
    else
        F_pool=[0.1,0.8,1.0];
        F=F_pool(randi(3));
        v=Population(xr1).decs+F*(Population(i).decs-Population(xr1).decs)+F*(Population(xr2).decs-Population(xr3).decs);
    end
    
    Lower  = repmat(Problem.lower,N,1);
    Upper  = repmat(Problem.upper,N,1);
    v      = min(max(v,Lower),Upper);
    Site   = rand(N,D) < CR;
    j_rand = floor(rand * D) + 1;
    Site(1, j_rand) = 1;
    Site_  = 1-Site;
    trial(i, :) = Site.*v+Site_.*Population(i).decs;

    else
        
       
        if rand<0.5
            F_pool=[0.6,0.8,1.0];
            F=F_pool(randi(3));
            v=  Population(i).decs+rand*(Population(xr1).decs-Population(i).decs)+F*(Population(xr2).decs-Population(xr3).decs);
        else
            F_pool=[0.1,0.8,1.0];
            F=F_pool(randi(3));
            v      = Population(i).decs+F*(Best_index-Population(i).decs)+F*(Population(xr1).decs-Population(xr2).decs);
        end
        
        Lower = repmat(Problem.lower,N,1);
        Upper = repmat(Problem.upper,N,1);
        trial(i, :) = min(max(v,Lower),Upper);
end












           
        
    end
    Offspring = trial;
    Offspring = SOLUTION(Offspring);
end